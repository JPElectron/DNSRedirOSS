# PS-reports.ps1 v1.10 r10/12/2016 for DNS Redirector v7.2.0.18

# This code is released under the same license as DNS Redirector
# http://dnsredirector.com

$file=$args[0]

If ($args[1] -eq 'response') {
$results = Select-String -Path $file -Pattern "(?<=sent: ).+(?= type)" | Select -Expand Matches | Select -Expand Value
}

If ($args[1] -eq 'blocked') {
$results = Select-String -Path $file -Pattern "(?<=: ).+(?= ->)" | Select -Expand Matches | Select -Expand Value
}

If ($args[1] -eq 'clients') {
$results = Select-String -Path $file -Pattern "(?<=:\d\d ).+(?= \[)" | Select -Expand Matches | Select -Expand Value
}

If ($args[1] -eq 'nxdforce') {
$results = Select-String -Path $file -Pattern "(?<=sent: ).+(?= NXDomain)" | Select -Expand Matches | Select -Expand Value
}

If ($args[1] -eq 'notfound') {
$results = Select-String -Path $file -Pattern "(?<=sent: ).+(?= type NOT FOUND)" | Select -Expand Matches | Select -Expand Value
}

$results | Group-Object | Select-Object Name,Count | Sort-Object Count -Descending